package utils;

public class TrieKey {
	short key;
	
	public TrieKey (short key){
		this.key = key;
	}
}
