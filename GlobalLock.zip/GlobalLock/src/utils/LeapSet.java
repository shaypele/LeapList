package utils;

public class LeapSet {
	public long key;
	public Object value;
	
	public LeapSet (long key, Object value){
		this.key = key;
		this.value = value;
	}
}
